<div class="main">
 <section>
	<div class="main-banner" style="background-image: url(img/main-banner-bg.jpg);">
	   <div class="main-banner-inner">
		  <div class="main-banner-top">
			 <div class="main-banner-subtitle">
				<span>Explore our metaverse</span>
				<span>Explore our metaverse</span>
			 </div>
			 <div class="main-banner-title">
				<svg xmlns="http://www.w3.org/2000/svg" width="857" height="124" viewBox="0 0 857 124"
				   fill="none">
				   <path
					  d="M0 115.143V8.85714H8.83464V0H70.6771V8.85714H79.5117V53.1429H44.1732V35.4286H35.3385V88.5714H44.1732V62H79.5117V115.143H70.6771V124H8.83464V115.143H0Z"
					  fill="#171B21" />
				   <path
					  d="M88.3521 8.85714V0H150.195V8.85714H159.029V124H123.691V88.5714H114.856V124H79.5175V8.85714H88.3521ZM114.856 35.4286V53.1429H123.691V35.4286H114.856Z"
					  fill="#171B21" />
				   <path d="M159.035 0H229.712V8.85714H238.547V124H203.208V35.4286H194.374V124H159.035V0Z"
					  fill="#171B21" />
				   <path
					  d="M238.552 70.8571V0H273.891V44.2857H291.56V0H326.899V70.8571H318.064V88.5714H309.23V115.143H300.395V124H265.056V115.143H256.222V88.5714H247.387V70.8571H238.552Z"
					  fill="#171B21" />
				   <path
					  d="M335.676 8.85714V0H397.518V8.85714H406.353V124H371.014V88.5714H362.18V124H326.841V8.85714H335.676ZM362.18 35.4286V53.1429H371.014V35.4286H362.18Z"
					  fill="#171B21" />
				   <path
					  d="M406.359 88.5714H415.193V35.4286H406.359V0H459.367V35.4286H450.532V88.5714H459.367V124H406.359V88.5714Z"
					  fill="#171B21" />
				   <path
					  d="M459.418 79.7143H468.253V70.8571H459.418V8.85714H468.253V0H530.095V8.85714H538.93V44.2857H530.095V53.1429H538.93V115.143H530.095V124H468.253V115.143H459.418V79.7143ZM503.592 88.5714V79.7143H494.757V88.5714H503.592ZM494.757 44.2857H503.592V35.4286H494.757V44.2857Z"
					  fill="#171B21" />
				   <path d="M538.936 0H574.274V88.5714H618.448V124H538.936V0Z" fill="#171B21" />
				   <path
					  d="M627.288 8.85714V0H689.13V8.85714H697.965V124H662.626V88.5714H653.792V124H618.453V8.85714H627.288ZM653.792 35.4286V53.1429H662.626V35.4286H653.792Z"
					  fill="#171B21" />
				   <path d="M697.971 0H768.648V8.85714H777.483V124H742.144V35.4286H733.309V124H697.971V0Z"
					  fill="#171B21" />
				   <path
					  d="M777.488 0H848.165V8.85714H857V115.143H848.165V124H777.488V0ZM812.827 35.4286V88.5714H821.661V35.4286H812.827Z"
					  fill="#171B21" />
				   <path
					  d="M8.83116 8.83333V0H52.9869V8.83333H61.8181V35.3333H44.1558V17.6667H17.6623V88.3333H44.1558V61.8333H61.8181V97.1667H52.9869V106H8.83116V97.1667H0V8.83333H8.83116Z"
					  fill="white" />
				   <path
					  d="M79.4861 8.83333H88.3173V0H132.473V8.83333H141.304V106H123.642V70.6667H97.1485V106H79.4861V8.83333ZM123.642 53V17.6667H97.1485V53H123.642Z"
					  fill="white" />
				   <path d="M158.972 0H211.959V8.83333H220.79V106H203.128V17.6667H176.635V106H158.972V0Z"
					  fill="white" />
				   <path
					  d="M238.458 53V0H256.121V44.1667H264.952V70.6667H282.614V44.1667H291.445V0H309.108V53H300.277V70.6667H291.445V97.1667H282.614V106H264.952V97.1667H256.121V70.6667H247.29V53H238.458Z"
					  fill="white" />
				   <path
					  d="M326.712 8.83333H335.544V0H379.699V8.83333H388.531V106H370.868V70.6667H344.375V106H326.712V8.83333ZM370.868 53V17.6667H344.375V53H370.868Z"
					  fill="white" />
				   <path
					  d="M406.199 106V88.3333H415.03V17.6667H406.199V0H441.524V17.6667H432.693V88.3333H441.524V106H406.199Z"
					  fill="#BAD34A" />
				   <path
					  d="M459.238 79.5H476.9V88.3333H503.394V61.8333H468.069V53H459.238V8.83333H468.069V0H512.225V8.83333H521.056V26.5H503.394V17.6667H476.9V44.1667H512.225V53H521.056V97.1667H512.225V106H468.069V97.1667H459.238V79.5Z"
					  fill="#BAD34A" />
				   <path d="M538.724 0H556.386V88.3333H600.542V106H538.724V0Z" fill="#BAD34A" />
				   <path
					  d="M618.21 8.83333H627.041V0H671.197V8.83333H680.028V106H662.366V70.6667H635.873V106H618.21V8.83333ZM662.366 53V17.6667H635.873V53H662.366Z"
					  fill="#BAD34A" />
				   <path d="M697.696 0H750.683V8.83333H759.514V106H741.852V17.6667H715.359V106H697.696V0Z"
					  fill="#BAD34A" />
				   <path
					  d="M777.182 0H830.169V8.83333H839.001V97.1667H830.169V106H777.182V0ZM794.845 88.3333H821.338V17.6667H794.845V88.3333Z"
					  fill="#BAD34A" />
				</svg>
			 </div>
			 <div class="main-banner-ver">
				<span>VER. 1.25</span>
				<span>VER. 1.25</span>
			 </div>
			 <a href="/play">
				 <div class="main-banner-btn btn green">
					<span>play now</span>
				 </div>
			 </a>
		  </div>
		  <div class="main-banner-bottom">
			 <div class="main-banner-socs">
				<a href="<?=$contentData["links"]["discord"];?>" target="_blank" class="main-banner-soc sqr-block white">
				   <span>
					  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
						 fill="none">
						 <path
							d="M9.58 4.00015C9.3 4.00215 7.006 4.06715 4.584 5.87315C4.584 5.87315 2 10.5382 2 16.2812C2 16.2812 3.507 18.8742 7.473 19.0002C7.473 19.0002 8.137 18.2082 8.675 17.5232C6.397 16.8382 5.535 15.4152 5.535 15.4152C5.535 15.4152 5.715 15.5412 6.037 15.7222C6.055 15.7222 6.072 15.7412 6.107 15.7582C6.162 15.7932 6.215 15.8122 6.269 15.8482C6.717 16.1002 7.165 16.2982 7.579 16.4592C8.315 16.7662 9.194 17.0352 10.218 17.2332C11.564 17.4852 13.143 17.5752 14.864 17.2522C15.7564 17.0861 16.6289 16.8266 17.467 16.4782C18.1928 16.204 18.8847 15.8474 19.529 15.4152C19.529 15.4152 18.633 16.8732 16.282 17.5402C16.82 18.2062 17.467 18.9792 17.467 18.9792C21.432 18.8532 22.94 16.2592 22.94 16.2792C22.94 10.5332 20.356 5.87015 20.356 5.87015C17.79 3.94615 15.331 4.00015 15.331 4.00015L15.08 4.28815C18.13 5.20615 19.548 6.55815 19.548 6.55815C17.8744 5.64675 16.0411 5.06586 14.148 4.84715C12.9423 4.71295 11.7248 4.72504 10.522 4.88315C10.415 4.88315 10.325 4.90215 10.216 4.91815C9.588 4.99015 8.063 5.20615 6.143 6.05315C5.48 6.34115 5.084 6.55815 5.084 6.55815C5.084 6.55815 6.558 5.13515 9.787 4.21715L9.607 4.00015H9.579H9.58ZM9.123 10.6452C10.145 10.6452 10.972 11.5272 10.953 12.6262C10.953 13.7262 10.145 14.6082 9.123 14.6082C8.118 14.6082 7.293 13.7252 7.293 12.6262C7.293 11.5272 8.099 10.6452 9.123 10.6452ZM15.673 10.6452C16.677 10.6452 17.503 11.5272 17.503 12.6262C17.503 13.7262 16.694 14.6082 15.673 14.6082C14.667 14.6082 13.843 13.7252 13.843 12.6262C13.843 11.5272 14.649 10.6452 15.673 10.6452Z"
							fill="#171B21" />
					  </svg>
				   </span>
				</a>
				<a href="<?=$contentData["links"]["twitter"];?>" target="_blank" class="main-banner-soc sqr-block white">
				   <span>
					  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
						 fill="none">
						 <path
							d="M3.00024 18.291C4.99224 18.431 6.72824 17.947 8.32724 16.72C7.51124 16.622 6.80024 16.409 6.20024 15.934C5.61624 15.468 5.16824 14.887 4.92824 14.093H6.40824C6.41624 14.06 6.42424 14.027 6.43224 13.986C5.61624 13.749 4.92024 13.323 4.40024 12.644C3.88024 11.974 3.62524 11.196 3.60024 10.344C4.12024 10.492 4.61624 10.639 5.12024 10.778C5.13624 10.745 5.16024 10.713 5.17624 10.68C4.45624 10.074 3.93624 9.34598 3.74524 8.40498C3.54809 7.48719 3.68683 6.52913 4.13624 5.70498C6.13624 8.09398 8.64724 9.41998 11.7342 9.64098C11.6382 8.86298 11.6302 8.14298 11.8942 7.43898C12.8062 4.97598 15.8772 4.18998 17.7882 5.95798C18.0042 6.15398 18.1882 6.18698 18.4202 6.10498C19.0522 5.87598 19.6752 5.63098 20.3232 5.38498C20.0752 6.19498 19.5392 6.79298 18.9082 7.37398C19.5232 7.20998 20.1392 7.03798 20.7472 6.87398C20.7712 6.89898 20.7952 6.91498 20.8192 6.93998C20.3552 7.43098 19.9072 7.94698 19.4042 8.38898C19.1322 8.62598 19.0442 8.84698 19.0282 9.20698C18.8842 13.217 17.2762 16.457 13.8532 18.496C10.3662 20.566 6.77624 20.443 3.24124 18.471C3.17724 18.431 3.12124 18.381 3.00124 18.291H3.00024Z"
							fill="#171B21" />
					  </svg>
				   </span>
				</a>
				<a href="<?=$contentData["links"]["telegram"];?>" target="_blank" class="main-banner-soc sqr-block white">
				   <span>
					  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
						 fill="none">
						 <path
							d="M20.9822 5.07062C20.8756 6.63229 18.0143 18.2999 18.0143 18.2999C18.0143 18.2999 17.8366 18.982 17.2146 19C17.0013 19 16.717 18.982 16.3971 18.6769C15.7395 18.1204 14.2467 17.0434 12.8427 16.0562C12.7894 16.11 12.7361 16.1639 12.665 16.2177C12.3451 16.5049 11.8653 16.9178 11.3499 17.4204C11.1544 17.5999 10.9411 17.7973 10.7279 18.0127L10.7101 18.0307C10.5857 18.1563 10.4791 18.2461 10.3902 18.3179C9.69709 18.8923 9.62601 18.4076 9.62601 18.1563L9.99922 14.0457V14.0098L10.017 13.9739C10.0348 13.9201 10.0703 13.9021 10.0703 13.9021C10.0703 13.9021 17.339 7.36825 17.5345 6.66819C17.5523 6.63229 17.4989 6.59639 17.4101 6.63229C16.9302 6.79385 8.55969 12.143 7.63555 12.7354C7.58224 12.7713 7.42229 12.7533 7.42229 12.7533L3.35254 11.4071C3.35254 11.4071 2.8727 11.2096 3.03264 10.7608C3.06819 10.6711 3.1215 10.5813 3.31699 10.4557C4.22336 9.80948 19.987 4.08336 19.987 4.08336C19.987 4.08336 20.4313 3.93976 20.6979 4.02951C20.8223 4.08336 20.8934 4.13721 20.9645 4.31671C20.9822 4.38851 21 4.53212 21 4.69367C21 4.78342 20.9822 4.89112 20.9822 5.07062Z"
							fill="#171B21" />
					  </svg>
				   </span>
				</a>
			 </div>
			 <div class="main-banner-scroll">
				<svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" viewBox="0 0 44 44" fill="none">
				   <path
					  d="M19.1865 0.291016C14.9209 0.291016 11.4512 3.76029 11.4512 8.02539V21.9473C11.4512 26.2124 14.9209 29.6826 19.1865 29.6826H24.491C28.7556 29.6826 32.2254 26.2124 32.2254 21.9473V8.02539C32.2254 3.76029 28.7556 0.291016 24.491 0.291016H19.1865ZM19.1865 2.72087H24.491C27.4163 2.72087 29.7955 5.10012 29.7955 8.02539V21.9473H29.7946C29.7946 24.873 27.4153 27.2527 24.4901 27.2527H19.1865C16.2607 27.2527 13.8801 24.873 13.8801 21.9473V8.02539C13.8801 5.10012 16.2607 2.72087 19.1865 2.72087ZM21.8392 7.18018C21.1681 7.18018 20.6238 7.72446 20.6238 8.39558V12.005C20.6238 12.6761 21.1681 13.2204 21.8392 13.2204C22.5103 13.2204 23.0546 12.6761 23.0546 12.005V8.39558C23.0546 7.72446 22.5103 7.18018 21.8392 7.18018ZM21.8392 31.5543C21.1681 31.5543 20.6238 32.0977 20.6238 32.7688V39.8034L18.3214 37.789C17.8162 37.3481 17.0494 37.3999 16.6074 37.9042C16.1655 38.4095 16.2164 39.1763 16.7217 39.6183L21.0393 43.3948C21.27 43.5959 21.5545 43.6951 21.8383 43.6951H21.8392C22.123 43.6951 22.408 43.5955 22.6382 43.3939L26.9539 39.6183C27.4592 39.1763 27.5101 38.409 27.0682 37.9042C26.6272 37.399 25.8594 37.3485 25.3542 37.79L23.0537 39.8024V32.7688C23.0546 32.0981 22.5103 31.5543 21.8392 31.5543L21.8392 31.5543Z"
					  fill="white" />
				</svg>
			 </div>
			 <a href="<?=$contentData["links"]["opensea"];?>" class="main-banner-buy">
				<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48" fill="none">
				   <g clip-path="url(#clip0_0_319)">
					  <path
						 d="M24.2017 0.961026C11.318 0.853506 0.853506 11.318 0.961026 24.2017C1.06855 36.7129 11.2911 46.9354 23.7985 47.0391C36.6821 47.1505 47.1505 36.6821 47.0391 23.7985C46.9354 11.2911 36.7129 1.06855 24.2017 0.961026Z"
						 fill="#2081E2" />
					  <path
						 d="M17.7153 13.2666C19.0694 14.9874 19.8806 17.1632 19.8806 19.5263C19.8806 21.5716 19.2739 23.4762 18.2304 25.0664H10.8955L17.7158 13.2671L17.7153 13.2666Z"
						 fill="white" />
					  <path
						 d="M40.0801 27.6792C40.0801 27.7781 40.0273 27.8626 39.9356 27.9015C39.4383 28.1132 37.7986 28.8749 37.1141 29.8234C35.3545 32.2743 34.0109 36.1253 31.0061 36.1253H18.4695C14.0295 36.1253 10.3162 32.6021 10.3196 27.9087C10.3196 27.7925 10.4185 27.697 10.5346 27.697H16.4765C16.681 27.697 16.8433 27.8626 16.8433 28.0637V29.21C16.8433 29.82 17.3367 30.314 17.9473 30.314H22.454V27.6903H19.3753C21.1455 25.4472 22.2001 22.6157 22.2001 19.5336C22.2001 16.0954 20.881 12.96 18.7229 10.6152C20.0276 10.7669 21.2761 11.028 22.454 11.3736V10.6436C22.454 9.88517 23.0674 9.27173 23.8258 9.27173C24.5842 9.27173 25.1977 9.88517 25.1977 10.6436V12.4032C29.4049 14.3674 32.1591 17.6261 32.1591 21.3111C32.1591 23.473 31.214 25.4866 29.5815 27.1791C29.2676 27.5036 28.8337 27.6869 28.3791 27.6869H25.1981V30.3072H29.1903C30.0509 30.3072 31.5951 28.6748 32.329 27.6908C32.329 27.6908 32.3607 27.6413 32.4457 27.6168C32.5301 27.5924 39.7772 25.9277 39.7772 25.9277C39.9289 25.8855 40.0805 26.0016 40.0805 26.1567V27.6802L40.0801 27.6792Z"
						 fill="white" />
				   </g>
				   <defs>
					  <clipPath id="clip0_0_319">
						 <rect width="48" height="48" fill="white" />
					  </clipPath>
				   </defs>
				</svg>
				<div class="main-banner-buy-text">
				   <span>BUY ON OPENSEA</span>
				   <span>BUY ON OPENSEA</span>
				</div>
			 </a>
		  </div>
	   </div>
	</div>
 </section>
 <section>
	<div class="whatis" style="background-image: url(img/whatis-bg.png);">
	   <div class="whatis-inner">
		  <div class="whatis-title title">
			 <p>WHAT IS CANVAISLAD</p>
			 <p>WHAT IS CANVAISLAD</p>
		  </div>
		  <div class="whatis-text">The first island is 256 unique pieces of land in the form of NFTs on the
			 Ethereum network, divided into 5 levels. This island makes an investment sense for the
			 establishment of the base and development of the project. After acquiring the land, the owners will
			 gradually receive different benefits (PFP, tokens, NFT avatars of characters, access to a private
			 chat to manage the development of the island)</div>
		  <div class="whatis-video">
			 <iframe width="560" height="315" src="https://www.youtube.com/embed/LXb3EKWsInQ"
				title="YouTube video player" frameborder="0"
				allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
				allowfullscreen></iframe>
			 <div class="what-is-bottom-text">*A free-to-play life sim farming RPG, coming to PC & mobile soon
			 </div>
			 <div class="whatis-video-bg">
				<img src="img/whatis-video-bg.png" alt="">
			 </div>
		  </div>
	   </div>
	</div>
 </section>
 <section>
	<div class="genesis" style="background-image: url(img/genesis-bg.png);">
	   <div class="container">
		  <div class="genesis-inner">
			 <div class="genesis-l content-col">
				<div class="genesis-suptitle content-col-suptitle">Discover a new world</div>
				<div class="genesis-title title content-col-title">
				   <p>GENESIS ISLAND</p>
				   <p>GENESIS ISLAND</p>
				</div>
				<div class="genesis-text content-col-text">The first island is 256 unique pieces of land in the
				   form of NFTs on
				   the Ethereum network, divided into 5 levels. This island makes an investment sense for the
				   establishment of the base and development of the project. After acquiring the land, the
				   owners will gradually receive different benefits (PFP, tokens, NFT avatars of characters,
				   access to a private chat to manage the development of the island), you can find out more in
				   our whitepaper.</div>
				<a href="/island" class="genesis-link content-col-link">
				   More about island
				   <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21"
					  fill="none">
					  <path
						 d="M12.6703 6C12.399 6.00007 12.1548 6.16451 12.0527 6.41585C11.9507 6.66719 12.011 6.95532 12.2055 7.14453L14.4008 9.33985H4.01015C3.76972 9.33645 3.5461 9.46276 3.42489 9.67042C3.30368 9.87809 3.30368 10.1349 3.42489 10.3426C3.5461 10.5503 3.76972 10.6766 4.01015 10.6732H14.4008L12.2055 12.8685C12.0313 13.0357 11.9611 13.284 12.022 13.5176C12.083 13.7512 12.2654 13.9337 12.499 13.9946C12.7327 14.0555 12.981 13.9853 13.1482 13.8112L16.4229 10.5365C16.5879 10.4107 16.685 10.2153 16.6855 10.0078C16.686 9.80032 16.5899 9.60443 16.4255 9.47786C16.4242 9.47698 16.4229 9.47612 16.4216 9.47525L13.1482 6.20181C13.0226 6.07279 12.8503 6.00001 12.6703 6Z"
						 fill="#BAD34A" />
				   </svg>
				</a>
				<div class="genesis-btns content-col-btns">
					<a href="/island">
					   <div class="genesis-btn content-col-btn btn green">
						  <span>BUY LANDS</span>
					   </div>
				   </a>
				   <a href="/play">
					   <div  class="genesis-btn content-col-btn btn">
						  <span>PLAY NOW</span>
					   </div>
				   </a>
				</div>
			 </div>
			 <a href="/island">
				 <div class="genesis-r">
					<div class="genesis-img">
					   <img src="img/genesis-img.png" alt="">
					   <div class="genesis-btn btn transparent">
						  <span>ISLAND VIEW</span>
					   </div>
					</div>
				 </div>
			 </a>
		  </div>
	   </div>
	</div>
 </section>
 <section>
	<div class="profile" style="background-image: url(img/profile-bg.png);">
	   <div class="container">
		  <div class="profile-inner">
		  
			 <div class="profile-l">
				<div class="profile-items" id="profileItems">
					<!-- avatar examples -->
				</div>
				<div class="profile-refresh" id="refreshButton">
				   <svg xmlns="http://www.w3.org/2000/svg" width="26" height="24" viewBox="0 0 26 24"
					  fill="none">
					  <g opacity="0.43">
						 <path
							d="M13 2.40002C10.6251 2.40002 8.44225 3.26678 6.76562 4.70002C6.53678 4.8822 6.4256 5.17474 6.47566 5.46293C6.52573 5.75111 6.72907 5.98901 7.00595 6.08332C7.28283 6.17764 7.58911 6.11334 7.80468 5.91565C9.20325 4.7201 11.0133 4.00002 13 4.00002C17.1572 4.00002 20.5608 7.15037 20.9609 11.2H18.6L21.8 16L25 11.2H22.5594C22.1503 6.28135 18.0223 2.40002 13 2.40002ZM4.2 8.00002L1 12.8H3.44062C3.84965 17.7187 7.97772 21.6 13 21.6C15.3749 21.6 17.5577 20.7333 19.2344 19.3C19.4632 19.1178 19.5744 18.8253 19.5243 18.5371C19.4743 18.2489 19.2709 18.011 18.994 17.9167C18.7172 17.8224 18.4109 17.8867 18.1953 18.0844C16.7967 19.2799 14.9867 20 13 20C8.84275 20 5.43921 16.8497 5.03906 12.8H7.4L4.2 8.00002Z"
							fill="white" stroke="white" />
					  </g>
				   </svg>
				   <span>Refresh</span>
				</div>
			 </div>
			 
			 <div class="profile-r">
				<div class="content-col">
				   <div class="profile-suptitle content-col-suptitle">Create your own unique</div>
				   <div class="profile-title title content-col-title">
					  <p>PROFILE AVATARS</p>
					  <p>PROFILE AVATARS</p>
				   </div>
				   <div class="profile-text content-col-text">10,000 profile avatars in the form of NFT ERC-721
					  on
					  the Ethereum blockchain with a price of 0.05 ETH + gas. These avatars will help you stand
					  out
					  in our metaverse, and can also be used as a PFP for social networks. In addition, various
					  competitions and exhibitions will be organized among the owners. Read more in the
					  whitepaper.
				   </div>
				   <a href="/avatars" class="profile-link content-col-link">
					  More about avatars
					  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21"
						 fill="none">
						 <path
							d="M12.6703 6C12.399 6.00007 12.1548 6.16451 12.0527 6.41585C11.9507 6.66719 12.011 6.95532 12.2055 7.14453L14.4008 9.33985H4.01015C3.76972 9.33645 3.5461 9.46276 3.42489 9.67042C3.30368 9.87809 3.30368 10.1349 3.42489 10.3426C3.5461 10.5503 3.76972 10.6766 4.01015 10.6732H14.4008L12.2055 12.8685C12.0313 13.0357 11.9611 13.284 12.022 13.5176C12.083 13.7512 12.2654 13.9337 12.499 13.9946C12.7327 14.0555 12.981 13.9853 13.1482 13.8112L16.4229 10.5365C16.5879 10.4107 16.685 10.2153 16.6855 10.0078C16.686 9.80032 16.5899 9.60443 16.4255 9.47786C16.4242 9.47698 16.4229 9.47612 16.4216 9.47525L13.1482 6.20181C13.0226 6.07279 12.8503 6.00001 12.6703 6Z"
							fill="#BAD34A" />
					  </svg>
				   </a>
				   <div class="profile-btns content-col-btns">
					  <a href="/avatars" target="_blank">
						  <div class="profile-btn content-col-btn btn green">
							 <span>MINT</span>
						  </div>
					  </a>
					  <a href="<?=$contentData["links"]["opensea"];?>" target="_blank">
						  <div class="profile-btn content-col-btn btn">
							 <span>OPENSEA</span>
						  </div>
					  </a>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
 </section>
 <section>
	<div class="nametoken">
	   <div class="container">
		  <div class="nametoken-inner">
			 <div class="nametoken-l">
				<div class="content-col">
				   <div class="nametoken-suptitle content-col-suptitle">Get something new</div>
				   <div class="nametoken-title title content-col-title">
					  <p><span class="green">$NAME</span> tOKEN</p>
					  <p>$NAME tOKEN</p>
				   </div>
				   <div class="nametoken-text content-col-text">10,000 profile avatars in the form of NFT
					  ERC-721
					  on the Ethereum blockchain with a price of 0.05 ETH + gas. These avatars will help you
					  stand out in our metaverse, and can also be used as a PFP for social networks. In
					  addition, various competitions and exhibitions will be organized among the owners. Read
					  more in the whitepaper.<br><br>10,000 profile avatars in the form of NFT ERC-721 on the
					  Ethereum blockchain with a price of 0.05 ETH + gas. These avatars will help you stand out
					  in our metaverse</div>
				   <a href="/token" class="nametoken-link content-col-link">
					  More about NAME
					  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21"
						 fill="none">
						 <path
							d="M12.6703 6C12.399 6.00007 12.1548 6.16451 12.0527 6.41585C11.9507 6.66719 12.011 6.95532 12.2055 7.14453L14.4008 9.33985H4.01015C3.76972 9.33645 3.5461 9.46276 3.42489 9.67042C3.30368 9.87809 3.30368 10.1349 3.42489 10.3426C3.5461 10.5503 3.76972 10.6766 4.01015 10.6732H14.4008L12.2055 12.8685C12.0313 13.0357 11.9611 13.284 12.022 13.5176C12.083 13.7512 12.2654 13.9337 12.499 13.9946C12.7327 14.0555 12.981 13.9853 13.1482 13.8112L16.4229 10.5365C16.5879 10.4107 16.685 10.2153 16.6855 10.0078C16.686 9.80032 16.5899 9.60443 16.4255 9.47786C16.4242 9.47698 16.4229 9.47612 16.4216 9.47525L13.1482 6.20181C13.0226 6.07279 12.8503 6.00001 12.6703 6Z"
							fill="#BAD34A" />
					  </svg>
				   </a>
				   <div class="nametoken-btns content-col-btns">
				      <a href="/token" target="_blank">
						  <div class="nametoken-btn content-col-btn btn green">
							 <span>BUY $NAME</span>
						  </div>
					  </a>
				   </div>
				</div>
			 </div>
			 <div class="nametoken-r">
				<div class="nametoken-diagramm">
				   <div class="nametoken-diagram-img">
					  <svg xmlns="http://www.w3.org/2000/svg" width="293" height="294" viewBox="0 0 293 294"
						 fill="none">
						 <circle cx="146.5" cy="147" r="146.5" fill="#D479DC" />
						 <path
							d="M146.5 0.5C184.956 0.5 221.869 15.6206 249.274 42.5985C276.679 69.5763 292.378 106.248 292.982 144.699C293.586 183.15 279.047 220.296 252.503 248.122C225.959 275.947 189.538 292.22 151.102 293.428C112.665 294.636 75.2945 280.682 47.0556 254.578C18.8168 228.474 1.97412 192.314 0.16263 153.901C-1.64886 115.488 11.7161 77.903 37.3731 49.2577C63.03 20.6123 98.9215 3.20371 137.301 0.789078L146.5 147L146.5 0.5Z"
							fill="#79DCAC" />
						 <path
							d="M146.5 0.5C180.986 0.5 214.367 12.6662 240.766 34.8567C267.165 57.0472 284.889 87.8394 290.819 121.812C296.748 155.785 290.502 190.761 273.181 220.582C255.859 250.403 228.573 273.157 196.125 284.839C163.677 296.521 128.149 296.381 95.7938 284.445C63.4389 272.509 36.3321 249.541 19.2455 219.585C2.15884 189.629 -3.81211 154.605 2.38376 120.68C8.57964 86.7543 26.5451 56.1023 53.1174 34.1198L146.5 147L146.5 0.5Z"
							fill="#DADC79" />
						 <path
							d="M146.5 0.5C177.831 0.5 208.337 10.5445 233.539 29.159C258.741 47.7734 277.311 73.9771 286.524 103.923C295.736 133.869 295.106 165.98 284.725 195.541C274.343 225.102 254.759 250.557 228.845 268.167C202.932 285.778 172.055 294.617 140.748 293.387C109.442 292.157 79.3536 280.923 54.9019 261.333C30.4502 241.744 12.9229 214.831 4.89308 184.546C-3.13673 154.262 -1.24598 122.201 10.2878 93.0697L146.5 147L146.5 0.5Z"
							fill="#79ACDC" />
						 <path
							d="M146.5 0.5C171.956 0.5 196.973 7.13307 219.085 19.7455C241.197 32.3579 259.641 50.5143 272.599 72.4254C285.557 94.3365 292.582 119.246 292.982 144.699C293.382 170.152 287.142 195.27 274.879 217.577C262.615 239.884 244.751 258.611 223.046 271.912C201.341 285.213 176.545 292.628 151.102 293.428C125.658 294.227 100.445 288.383 77.9483 276.472C55.4511 264.56 36.446 246.992 22.806 225.499L146.5 147L146.5 0.5Z"
							fill="#BAD34A" />
						 <path
							d="M146.5 0.5C173.518 0.5 200.01 7.97142 223.046 22.0882C246.083 36.205 264.767 56.4173 277.032 80.4904C289.298 104.563 294.668 131.56 292.548 158.494C290.429 185.429 280.902 211.253 265.021 233.111L146.5 147L146.5 0.5Z"
							fill="#BA5348" />
						 <path
							d="M146.5 0.5C171.176 0.5 195.453 6.73315 217.077 18.6211C238.701 30.509 256.972 47.6664 270.194 68.5014C283.416 89.3363 291.161 113.174 292.711 137.801C294.26 162.429 289.564 187.049 279.057 209.377L146.5 147L146.5 0.5Z"
							fill="#7B79DC" />
						 <path
							d="M146.5 0.5C165.739 0.5 184.789 4.28934 202.563 11.6517C220.337 19.014 236.487 29.8051 250.091 43.4089C263.695 57.0127 274.486 73.1627 281.848 90.9369C289.211 108.711 293 127.761 293 147L146.5 147L146.5 0.5Z"
							fill="#EAB585" />
					  </svg>
				   </div>
				   <div class="nametoken-diagram-item nametoken-diagram-item-1">
					  <div class="nametoken-diagram-item-title">Airdrop , Events</div>
					  <div class="nametoken-diagram-item-per">1%</div>
					  <div class="nametoken-diagram-item-line">
						 <svg xmlns="http://www.w3.org/2000/svg" width="164" height="45" viewBox="0 0 164 45"
							fill="none">
							<path d="M0 1H120L162.5 43.5" stroke="white" stroke-width="2" />
						 </svg>
					  </div>
				   </div>
				   <div class="nametoken-diagram-item nametoken-diagram-item-2">
					  <div class="nametoken-diagram-item-title">Marketing</div>
					  <div class="nametoken-diagram-item-per">10%</div>
					  <div class="nametoken-diagram-item-line">
						 <svg xmlns="http://www.w3.org/2000/svg" width="200" height="2" viewBox="0 0 200 2"
							fill="none">
							<path d="M0 1H200" stroke="white" stroke-width="2" />
						 </svg>
					  </div>
				   </div>
				   <div class="nametoken-diagram-item nametoken-diagram-item-3">
					  <div class="nametoken-diagram-item-title">Team</div>
					  <div class="nametoken-diagram-item-per">8%</div>
					  <div class="nametoken-diagram-item-line">
						 <svg xmlns="http://www.w3.org/2000/svg" width="204" height="45" viewBox="0 0 204 45"
							fill="none">
							<path d="M0 44H160L202.5 1.5" stroke="white" stroke-width="2" />
						 </svg>
					  </div>
				   </div>
				   <div class="nametoken-diagram-item nametoken-diagram-item-4">
					  <div class="nametoken-diagram-item-title">Treasury</div>
					  <div class="nametoken-diagram-item-per">15%</div>
					  <div class="nametoken-diagram-item-line">
						 <svg xmlns="http://www.w3.org/2000/svg" width="78" height="39" viewBox="0 0 78 39"
							fill="none">
							<path d="M0 38H40L76.5 1.5" stroke="white" stroke-width="2" />
						 </svg>
					  </div>
				   </div>
				   <div class="nametoken-diagram-item aifs nametoken-diagram-item-5">
					  <div class="nametoken-diagram-item-title">Staking</div>
					  <div class="nametoken-diagram-item-per">25%</div>
					  <div class="nametoken-diagram-item-line">
						 <svg xmlns="http://www.w3.org/2000/svg" width="93" height="55" viewBox="0 0 93 55"
							fill="none">
							<path d="M93 1.5H53L1 53.5" stroke="white" stroke-width="2" />
						 </svg>
					  </div>
				   </div>
				   <div class="nametoken-diagram-item aifs nametoken-diagram-item-6">
					  <div class="nametoken-diagram-item-title">Pre Sale</div>
					  <div class="nametoken-diagram-item-per">7%</div>
					  <div class="nametoken-diagram-item-line">
						 <svg xmlns="http://www.w3.org/2000/svg" width="132" height="55" viewBox="0 0 132 55"
							fill="none">
							<path d="M132 1.5H53L1 53.5" stroke="white" stroke-width="2" />
						 </svg>
					  </div>
				   </div>
				   <div class="nametoken-diagram-item aifs nametoken-diagram-item-7">
					  <div class="nametoken-diagram-item-title">Liquidity</div>
					  <div class="nametoken-diagram-item-per">3%</div>
					  <div class="nametoken-diagram-item-line">
						 <svg xmlns="http://www.w3.org/2000/svg" width="169" height="20" viewBox="0 0 169 20"
							fill="none">
							<path d="M169 1H19L1 19" stroke="white" stroke-width="2" />
						 </svg>
					  </div>
				   </div>
				   <div class="nametoken-diagram-item aifs nametoken-diagram-item-8">
					  <div class="nametoken-diagram-item-title">Play to earn</div>
					  <div class="nametoken-diagram-item-per">31%</div>
					  <div class="nametoken-diagram-item-line">
						 <svg xmlns="http://www.w3.org/2000/svg" width="93" height="54" viewBox="0 0 93 54"
							fill="none">
							<path d="M93 53H53L1 1" stroke="white" stroke-width="2" />
						 </svg>
					  </div>
				   </div>
				</div>
				<div class="nametoken-total">
				   Total: <span>600k</span>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
 </section>
 <section>
	<div class="main-favs">
	   <div class="main-favs-row">
		  <div class="main-favs-row-bg" style="background-image: url(img/main-favs-1.png);"></div>
		  <div class="main-favs-row-bg-mob" style="background-image: url(img/main-favs-mob-1.png);"></div>
		  <div class="container">
			 <div class="main-favs-row-inner">
				<div class="main-favs-row-content">
				   <div class="main-favs-row-title title">
					  <p><span class="green">swap</span> token</p>
					  <p>swap token</p>
				   </div>
				   <div class="main-favs-row-text">10,000 profile avatars in the form of NFT ERC-721 on the
					  Ethereum blockchain with a price of 0.05 ETH + gas. These avatars will help you stand out
					  in our metaverse, and can also be used as a PFP for social networks.</div>
				</div>
			 </div>
		  </div>
	   </div>
	   <div class="main-favs-row">
		  <div class="main-favs-row-bg" style="background-image: url(img/main-favs-2.png);"></div>
		  <div class="main-favs-row-bg-mob" style="background-image: url(img/main-favs-mob-2.png);"></div>
		  <div class="container">
			 <div class="main-favs-row-inner">
				<div class="main-favs-row-content">
				   <div class="main-favs-row-title title">
					  <p><span class="green">tOKEN</span> STAKING</p>
					  <p>tOKEN STAKING</p>
				   </div>
				   <div class="main-favs-row-text">10,000 profile avatars in the form of NFT ERC-721 on the
					  Ethereum blockchain with a price of 0.05 ETH + gas. These avatars will help you stand out
					  in our metaverse, and can also be used as a PFP for social networks.</div>
				</div>
			 </div>
		  </div>
	   </div>
	   <div class="main-favs-row">
		  <div class="main-favs-row-bg" style="background-image: url(img/main-favs-3.png);"></div>
		  <div class="main-favs-row-bg-mob" style="background-image: url(img/main-favs-mob-3.png);"></div>
		  <div class="container">
			 <div class="main-favs-row-inner">
				<div class="main-favs-row-content">
				   <div class="main-favs-row-title title">
					  <p><span class="green">REFERRAL</span> PROGRAM</p>
					  <p>REFERRAL PROGRAM</p>
				   </div>
				   <div class="main-favs-row-text">10,000 profile avatars in the form of NFT ERC-721 on the
					  Ethereum blockchain with a price of 0.05 ETH + gas. These avatars will help you stand out
					  in our metaverse, and can also be used as a PFP for social networks.</div>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
 </section>
 <section>
	<div class="roadmap" id="roadmap">
	   <div class="roadmap-inner">
		  <div class="container">
			 <div class="roadmap-content">
				<div class="roadmap-title title">
				   <p>PROJECT ROADMAP</p>
				   <p>PROJECT ROADMAP</p>
				</div>
				<div class="roadmap-text">A free-to-play life sim farming RPG, coming to PC & mobile soon</div>
			 </div>
			 <div class="roadmap-body-wrapper">
				<div class="roadmap-body">
				   <div class="roadmap-body-slider swiper">
					  <div class="swiper-wrapper">
						<?php			
							foreach ($contentData['roadmap'] as $phase) {
								echo '<div class="swiper-slide">';
								
								echo '<div class="roadmap-body-step">';
								echo '<div class="roadmap-body-step-top">';
								echo '<div class="roadmap-body-top-item">' . $phase['phase'] . '</div>';
								echo '</div>';
								echo '<div class="roadmap-body-step-bottom">';
								
								foreach ($phase['blocks'] as $block) {
									echo '<div class="roadmap-body-bottom-item">';
									echo '<div class="roadmap-body-bottom-item-title">' . $block['title'] . '</div>';
									echo '<div class="roadmap-body-bottom-item-ul">';
									
									foreach ($block['items'] as $item) {
										$activeClass = $item['active'] ? ' active' : '';
										echo '<div class="roadmap-body-bottom-item-li' . $activeClass . '">' . $item['title'] . '</div>';
									}
									
									echo '</div>';
									echo '</div>';
								}
								
								echo '</div>';
								echo '</div>';
								
								echo '</div>';
							}
						?>
					  </div>
				   </div>

				<div class="roadmap-body-mob-slider swiper">
				  <div class="swiper-wrapper">
					<?php
					foreach ($contentData['roadmap'] as $roadmapItem) {
						
						$phase = $roadmapItem['phase'];
						
						echo '<div class="swiper-slide">';
						echo '<div class="roadmap-body-bottom-item">';
						echo '<div class="roadmap-body-step-top">';
						echo '<div class="roadmap-body-top-item">' . $phase . '</div>';
						echo '</div>';
						echo '<div class="roadmap-body-bottom-item-title">' . $roadmapItem['blocks'][0]['title'] . '</div>';
						echo '<div class="roadmap-body-bottom-item-ul">';
						
						foreach ($roadmapItem['blocks'][0]['items'] as $item) {
							$activeClass = $item['active'] ? ' active' : '';
							echo '<div class="roadmap-body-bottom-item-li' . $activeClass . '">' . $item['title'] . '</div>';
						}
						
						echo '</div>';
						echo '</div>';
						echo '</div>';
						
						$first_block = true;
						
						foreach ($roadmapItem['blocks'] as $block) {
							
							if($first_block){
								$first_block = false;
							}else{
								echo '<div class="swiper-slide">';
								echo '<div class="roadmap-body-bottom-item">';
								echo '<div class="roadmap-body-bottom-item-title">' . $block['title'] . '</div>';
								echo '<div class="roadmap-body-bottom-item-ul">';
								
								foreach ($block['items'] as $item) {
									$activeClass = $item['active'] ? ' active' : '';
									echo '<div class="roadmap-body-bottom-item-li' . $activeClass . '">' . $item['title'] . '</div>';
								}
								
								echo '</div>';
								echo '</div>';
								echo '</div>';
							}
						}
						
					}
					?>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
 </section>
 <section>
	<div class="enter">
	   <div class="container">
		  <div class="enter-inner">
			 <div class="enter-l">
				<div class="enter-title title">
				   <p>ENTER
					  <span class="green">CANVAISLAND</span> THrough
					  mobile gaming
				   </p>
				   <p>ENTER
					  CANVAISLAND THrough
					  mobile gaming</p>
				</div>
				<div class="enter-text">Buy and sell LAND, Estates, Avatar wearables and names in the
				   Decentraland Marketplace: stocking the very best digital goods and paraphernalia backed by
				   the ethereum blockchain.</div>
				<div class="enter-items">
				   <div class="enter-item">
					  <p>4,8 <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
							fill="none">
							<path
							   d="M12 17.27L18.18 21L16.54 13.97L22 9.24L14.81 8.62L12 2L9.19 8.62L2 9.24L7.45 13.97L5.82 21L12 17.27Z"
							   fill="#BAD34A" />
						 </svg></p>
					  <p>Ср. оценка</p>
				   </div>
				   <div class="enter-item">
					  <p>5 млн</p>
					  <p>Cкачиваний</p>
				   </div>
				   <div class="enter-item">
					  <p>1000+</p>
					  <p>Отзывов</p>
				   </div>
				</div>
				<div class="enter-img mob">
				   <img src="img/enter-img.png" alt="">
				</div>
				<div class="enter-btns">
				   <a href="<?=$contentData["links"]["googleplay"];?>" class="enter-btn">
					  <img src="img/google-btn.png" alt="">
				   </a>
				   <a href="<?=$contentData["links"]["appstore"];?>" class="enter-btn">
					  <img src="img/appstore-btn.png" alt="">
				   </a>
				</div>
			 </div>
			 <div class="enter-r">
				<div class="enter-img">
				   <img src="img/enter-img.png" alt="">
				</div>
			 </div>
		  </div>
	   </div>
	</div>
 </section>
 <section>
	<div class="main-bottom-block" style="background-image: url(img/main-bottom-block-bg.png);">
	   <div class="container">
		  <div class="main-bottom-block-inner">
			 <div class="main-bottom-block-slider swiper">
				<div class="swiper-wrapper">
				   <div class="swiper-slide">
					  <div class="main-bottom-block-slide">
						 <img src="img/main-bottom-block-1.png" alt="">
					  </div>
				   </div>
				   <div class="swiper-slide">
					  <div class="main-bottom-block-slide">
						 <img src="img/main-bottom-block-2.png" alt="">
					  </div>
				   </div>
				   <div class="swiper-slide">
					  <div class="main-bottom-block-slide">
						 <img src="img/main-bottom-block-1.png" alt="">
					  </div>
				   </div>
				   <div class="swiper-slide">
					  <div class="main-bottom-block-slide">
						 <img src="img/main-bottom-block-2.png" alt="">
					  </div>
				   </div>
				   <div class="swiper-slide">
					  <div class="main-bottom-block-slide">
						 <img src="img/main-bottom-block-1.png" alt="">
					  </div>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
 </section>
</div>




<script>
document.addEventListener('DOMContentLoaded', function() {
	
	const profileItems = document.getElementById('profileItems');
	const refreshButton = document.getElementById('refreshButton');
	
	const imagePaths = [
		'img/avatars/examples/1.png',
		'img/avatars/examples/2.png',
		'img/avatars/examples/3.png',
		'img/avatars/examples/4.png',
		'img/avatars/examples/5.png',
		'img/avatars/examples/6.png',
		'img/avatars/examples/7.png',
		'img/avatars/examples/8.png',
		'img/avatars/examples/9.png',
		'img/avatars/examples/10.png'
	];
	
	function getRandomElement(array) {
		return array[Math.floor(Math.random() * array.length)];
	}
	
	function removeElementFromArray(array, element) {
		const index = array.indexOf(element);
		if (index !== -1) {
			array.splice(index, 1);
		}
	}
	
	function updateProfileImages() {
		profileItems.innerHTML = '';
		const availableImagePaths = [...imagePaths];
		
		for (let i = 0; i < 6; i++) { 
			if (availableImagePaths.length === 0) {
			break; 
			}
		
			const randomImagePath = getRandomElement(availableImagePaths);
		
			const profileItem = document.createElement('div');
			profileItem.className = 'profile-item';
		
			const profileItemImg = document.createElement('div');
			profileItemImg.className = 'profile-item-img';
		
			const img = document.createElement('img');
			img.src = randomImagePath;
			img.alt = '';
		
			profileItemImg.appendChild(img);
			profileItem.appendChild(profileItemImg);
		
			profileItems.appendChild(profileItem);
		
			removeElementFromArray(availableImagePaths, randomImagePath);
		}
	}
	
	updateProfileImages();
	
	refreshButton.addEventListener('click', function() {
		updateProfileImages();
	});
	
});
</script>